'use server'

import { revalidatePath } from 'next/cache'
import { sql } from '@/lib/db'
import { requirePerm, requireBilling } from '@/lib/auth'
import { interventionSchema, toDbValues, type AccessoryLine } from '@/lib/schemas/intervention'
import { isBillable, notifyBilling, isBillingEmailEnabled } from '@/lib/billing-notification'
import { headers } from 'next/headers'
import { resolveClientId } from '@/lib/intranet'

async function appUrl() {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, '')
  const h = await headers()
  return `${h.get('x-forwarded-proto') ?? 'http'}://${h.get('x-forwarded-host') ?? h.get('host')}`
}

/** Junta linhas repetidas do mesmo acessório somando as quantidades */
const merge = (lines: AccessoryLine[]) => {
  const m = new Map<string, number>()
  for (const l of lines) m.set(l.accessory_id, Math.min(99, (m.get(l.accessory_id) ?? 0) + l.quantity))
  return [...m.entries()].map(([accessory_id, quantity]) => ({ accessory_id, quantity }))
}

export async function createIntervention(input: unknown) {
  try {
    const user = await requirePerm('interventions', 'write')
    const parsed = interventionSchema.safeParse(input)
    if (!parsed.success) {
      return { success: false as const, error: parsed.error.issues.map(i => i.message).join('; ') }
    }
    const client_id = await resolveClientId(parsed.data.client_id)
    // validação = criação do registo: data de hoje e validador = técnico com o email de quem está autenticado
    const [validator] = await sql<{ id: string }[]>`select id from technicians where lower(email) = lower(${user.email}) limit 1`
    const values = {
      ...toDbValues(parsed.data), client_id, created_by: user.email, material_migrated: true,
      validation_date: new Date().toLocaleDateString('sv-SE', { timeZone: 'Europe/Lisbon' }),
      validated_by: validator?.id ?? (parsed.data.validated_by || null),
    }
    const spent = merge(parsed.data.accessories_spent)
    const returned = merge(parsed.data.accessories_returned)

    const id = await sql.begin(async tx => {
      const [row] = await tx`insert into interventions ${tx(values)} returning id`
      const lines = [
        ...spent.map(l => ({ intervention_id: row.id, direction: 'gasto', ...l })),
        ...returned.map(l => ({ intervention_id: row.id, direction: 'retomado', ...l })),
      ]
      if (lines.length) await tx`insert into intervention_accessories ${tx(lines)}`
      await tx`select gestao_interv.sync_intervention_stock(${row.id})`
      await tx`select gestao_interv.supersede_corrections(${row.id})`
      return row.id as string
    })

    // Faturar = Sim → email automático à financeira, a partir da conta de quem gravou
    let emailWarning: string | undefined
    if (isBillable(parsed.data.billing) && (await isBillingEmailEnabled())) {
      const r = await notifyBilling(id, user, await appUrl())
      if (!r.ok) emailWarning = `O registo foi gravado, mas o email à financeira não foi enviado: ${r.error}`
    }

    revalidatePath('/interventions')
    revalidatePath('/reports')
    revalidatePath('/stock')
    return { success: true as const, id, emailWarning }
  } catch (e) {
    console.error('Erro ao criar intervenção:', e)
    return { success: false as const, error: (e as Error).message }
  }
}

/** Edição de um registo gravado (só admin). Substitui os acessórios. */
export async function updateIntervention(id: string, input: unknown) {
  try {
    const user = await requirePerm('interventions', 'write')
    if (!/^[0-9a-f-]{36}$/i.test(id)) return { success: false as const, error: 'Registo inválido.' }
    const parsed = interventionSchema.safeParse(input)
    if (!parsed.success) {
      return { success: false as const, error: parsed.error.issues.map(i => i.message).join('; ') }
    }
    const client_id = await resolveClientId(parsed.data.client_id)
    // a data de validação é a da criação do registo: não muda ao editar
    const { validation_date: _vd, ...rest } = toDbValues(parsed.data) // eslint-disable-line @typescript-eslint/no-unused-vars
    const values = { ...rest, client_id, updated_by: user.email, material_migrated: true }
    const spent = merge(parsed.data.accessories_spent)
    const returned = merge(parsed.data.accessories_returned)

    const before = await sql.begin(async tx => {
      const [prev] = await tx`select billing, billing_notified_at from interventions where id = ${id} for update`
      if (!prev) throw new Error('Registo não encontrado.')
      await tx`update interventions set ${tx(values)} where id = ${id}`
      await tx`delete from intervention_accessories where intervention_id = ${id}`
      const lines = [
        ...spent.map(l => ({ intervention_id: id, direction: 'gasto', ...l })),
        ...returned.map(l => ({ intervention_id: id, direction: 'retomado', ...l })),
      ]
      if (lines.length) await tx`insert into intervention_accessories ${tx(lines)}`
      await tx`select gestao_interv.sync_intervention_stock(${id})`
      await tx`select gestao_interv.supersede_corrections(${id})`
      return prev as { billing: string | null; billing_notified_at: string | null }
    })

    // só envia quando o registo PASSA a Faturar = Sim e ainda não tinha sido enviado
    // (registos antigos da folha que já eram "Sim" não geram email ao serem editados)
    let emailWarning: string | undefined
    if (isBillable(parsed.data.billing) && !isBillable(before.billing ?? undefined) && !before.billing_notified_at && (await isBillingEmailEnabled())) {
      const r = await notifyBilling(id, user, await appUrl())
      if (!r.ok) emailWarning = `As alterações foram gravadas, mas o email à financeira não foi enviado: ${r.error}`
    }

    revalidatePath('/interventions')
    revalidatePath(`/interventions/${id}`)
    revalidatePath('/reports')
    revalidatePath('/stock')
    return { success: true as const, id, emailWarning }
  } catch (e) {
    console.error('Erro ao editar intervenção:', e)
    return { success: false as const, error: (e as Error).message }
  }
}

/** Reenvia manualmente o email à financeira (ex.: após um erro) */
export async function resendBillingEmail(id: string) {
  const user = await requirePerm('interventions', 'write')
  if (!(await isBillingEmailEnabled()))
    return { ok: false as const, error: 'O envio de emails à financeira está desligado (Configurações › Email).' }
  const r = await notifyBilling(id, user, await appUrl())
  revalidatePath(`/interventions/${id}`)
  return r
}

/** Elimina uma intervenção (só admin). Apaga também os acessórios e os movimentos de stock dela. */
export async function deleteIntervention(id: string) {
  try {
    const user = await requirePerm('interventions', 'write')
    if (!/^[0-9a-f-]{36}$/i.test(id)) return { success: false as const, error: 'Registo inválido.' }
    const [row] = await sql`delete from interventions where id = ${id} returning id, intervention_date::text, license_plate`
    if (!row) return { success: false as const, error: 'Registo não encontrado.' }
    console.log(`Intervenção ${id} (${row.intervention_date} ${row.license_plate ?? ''}) eliminada por ${user.email}`)
    revalidatePath('/interventions')
    revalidatePath('/reports')
    revalidatePath('/stock')
    return { success: true as const }
  } catch (e) {
    return { success: false as const, error: (e as Error).message }
  }
}

/** Financeiro/admin: marca (ou desmarca) uma intervenção com Faturar = Sim como processada. Não mexe em mais nada. */
export async function setBillingProcessed(id: string, processed: boolean) {
  try {
    const user = await requireBilling()
    const [row] = await sql<{ billing: string | null }[]>`select billing from interventions where id = ${id}`
    if (!row) throw new Error('Intervenção não encontrada.')
    if (!isBillable(row.billing)) throw new Error('Só é possível processar intervenções com Faturar = Sim.')
    await sql`update interventions set
                billing_processed_at = ${processed ? sql`now()` : null},
                billing_processed_by = ${processed ? user.email : null}
              where id = ${id}`
    revalidatePath('/interventions')
    revalidatePath(`/interventions/${id}`)
    return { ok: true as const }
  } catch (e) {
    return { ok: false as const, error: (e as Error).message }
  }
}
