-- =============================================================================
-- Gestão de Intervenções — esquema PostgreSQL (Railway)
-- Idempotente: pode ser corrido várias vezes (npm run db:schema).
-- =============================================================================

create extension if not exists pgcrypto;   -- gen_random_uuid()
create schema if not exists gestao_interv;
set search_path = gestao_interv, public;

-- -----------------------------------------------------------------------------
-- Acessos (whitelist de emails Google + papel)
-- -----------------------------------------------------------------------------
create table if not exists profiles (
  email      text primary key check (email = lower(email)),
  role       text not null default 'user' check (role in ('admin', 'user')),
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------------
-- Tabelas de apoio (listas dos dropdowns)
-- -----------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'technicians', 'intervention_types', 'motives', 'actions_performed', 'equipment_list',
    'bundles', 'accessories', 'billing_options', 'intranet_accounts', 'warranty_options', 'platforms'
  ] loop
    execute format($f$
      create table if not exists gestao_interv.%1$I (
        id         uuid primary key default gen_random_uuid(),
        name       text not null check (btrim(name) <> ''),
        active     boolean not null default true,
        created_at timestamptz not null default now()
      );
      create unique index if not exists %1$s_name_uq on gestao_interv.%1$I (lower(name));
    $f$, t);
  end loop;
end $$;

create table if not exists warehouses (
  id         uuid primary key default gen_random_uuid(),
  name       text not null check (btrim(name) <> ''),
  type       text not null default 'ambos' check (type in ('saida', 'entrada', 'ambos')),
  active     boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists warehouses_name_uq on warehouses (lower(name));

-- Armazém virtual "Instalado Aluguer (Mobilizado)": equipamentos de ALUGUER instalados em viaturas continuam a ser da Frotcom
alter table warehouses drop constraint if exists warehouses_type_check;
alter table warehouses add constraint warehouses_type_check check (type in ('saida', 'entrada', 'ambos', 'mobilizado'));
insert into warehouses (name, type) select 'Instalado Aluguer (Mobilizado)', 'mobilizado'
 where not exists (select 1 from warehouses where type = 'mobilizado');
create or replace function gestao_interv.mobilized_wh() returns uuid language sql stable as $$
  select id from gestao_interv.warehouses where type = 'mobilizado' order by created_at limit 1
$$;

create table if not exists clients (
  id                      uuid primary key default gen_random_uuid(),
  name                    text not null check (btrim(name) <> ''),
  venda_aluguer           text,
  nos_vdf                 text,
  report_projeto_contrato text,
  active                  boolean not null default true,
  created_at              timestamptz not null default now()
);
-- nomes únicos só entre clientes não ligados à Intranet (os ligados usam o nome da Intranet, que pode repetir-se: venda/aluguer)
drop index if exists gestao_interv.clients_name_uq;
create unique index if not exists clients_name_unlinked_uq on clients (lower(name)) where intranet_account_id is null;
create index if not exists clients_name_idx on clients (lower(name));

-- -----------------------------------------------------------------------------
-- Intervenções (tabela principal — equivalente à folha "Validação de Formulários")
-- -----------------------------------------------------------------------------
create table if not exists interventions (
  id                       uuid primary key default gen_random_uuid(),

  intervention_date        date not null,
  validation_date          date,
  technician_id            uuid references technicians(id),
  client_id                uuid references clients(id),
  venda_aluguer            text,
  nos_vdf                  text,
  report_projeto           text,
  intervention_type_id     uuid references intervention_types(id),
  license_plate            text,
  imei                     text,
  equipment_id             uuid references equipment_list(id),
  warranty_rental          text,
  intranet_account         text,
  intranet_license_plate   text,
  motive_id                uuid references motives(id),
  motive_text              text,       -- motivo tal como escrito (histórico tem texto livre)
  action_description       text,
  assisted_material        text,

  spent_equipment          text,
  spent_equipment_imei     text,
  accessory_spent_1        text,
  accessory_spent_2        text,
  accessory_spent_3        text,
  accessory_spent_4        text,
  accessory_spent_5        text,

  equipment_return         text,
  accessory_return_1       text,
  accessory_return_2       text,
  accessory_return_3       text,
  accessory_return_4       text,
  accessory_return_5       text,

  billing                  text,
  billing_observations     text,
  billing_email            text,
  bundle_id                uuid references bundles(id),
  dtc_active_realtime      text,
  configuration            text,
  platform_id              uuid references platforms(id),
  canbus_via               text,       -- só existia no layout de 2022
  observations             text,
  wow                      text,
  services_status          text,
  validated_by             uuid references technicians(id),
  crm_vehicle              text,
  contract_addendum        text,
  zoho_form                text,
  stock_exit_warehouse_id  uuid references warehouses(id),
  stock_entry_warehouse_id uuid references warehouses(id),

  -- Auditoria / migração
  legacy_key               text unique,  -- chave da linha da Google Sheet (re-sincronização sem duplicar)
  legacy_layout            text,         -- 'atual' | '2022'
  created_by               text,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);

create index if not exists interventions_date_idx   on interventions (intervention_date desc);
create index if not exists interventions_client_idx on interventions (client_id);
create index if not exists interventions_tech_idx   on interventions (technician_id);
create index if not exists interventions_type_idx   on interventions (intervention_type_id);
create index if not exists interventions_plate_idx  on interventions (license_plate);
create index if not exists interventions_imei_idx   on interventions (imei);

create or replace function gestao_interv.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at := now(); return new; end $$;

drop trigger if exists interventions_touch on interventions;
create trigger interventions_touch before update on interventions
  for each row execute function gestao_interv.touch_updated_at();

-- =============================================================================
-- Material gasto / retomado ligado às listas de Equipamentos e Acessórios
-- (v2 — substitui os campos de texto spent_equipment / accessory_spent_1..5 / ...)
-- =============================================================================
alter table interventions
  add column if not exists spent_equipment_id  uuid references equipment_list(id),
  add column if not exists return_equipment_id uuid references equipment_list(id),
  add column if not exists material_migrated   boolean not null default false;

create table if not exists intervention_accessories (
  intervention_id uuid not null references interventions(id) on delete cascade,
  accessory_id    uuid not null references accessories(id),
  direction       text not null check (direction in ('gasto', 'retomado')),
  quantity        int  not null default 1 check (quantity > 0),
  primary key (intervention_id, accessory_id, direction)
);
create index if not exists intervention_accessories_acc_idx on intervention_accessories (accessory_id);

/**
 * Converte os campos de texto históricos (importados da Google Sheet) para as novas ligações.
 * Só trata registos com material_migrated = false. Nomes que não existem nas listas são
 * criados como INATIVOS (preservam o histórico sem aparecer nos dropdowns).
 */
create or replace function gestao_interv.backfill_material() returns int
language plpgsql as $$
declare n int;
begin
  -- equipamentos em falta
  insert into gestao_interv.equipment_list (name, active)
  select distinct on (lower(btrim(e))) btrim(e), false
  from gestao_interv.interventions i, unnest(array[i.spent_equipment, i.equipment_return]) e
  where not i.material_migrated and btrim(coalesce(e, '')) <> ''
  on conflict do nothing;

  -- acessórios em falta
  insert into gestao_interv.accessories (name, active)
  select distinct on (lower(btrim(a))) btrim(a), false
  from gestao_interv.interventions i,
       unnest(array[i.accessory_spent_1, i.accessory_spent_2, i.accessory_spent_3, i.accessory_spent_4, i.accessory_spent_5,
                    i.accessory_return_1, i.accessory_return_2, i.accessory_return_3, i.accessory_return_4, i.accessory_return_5]) a
  where not i.material_migrated and btrim(coalesce(a, '')) <> ''
  on conflict do nothing;

  -- equipamento gasto / retomado
  update gestao_interv.interventions i set
    spent_equipment_id  = (select q.id from gestao_interv.equipment_list q where lower(q.name) = lower(btrim(i.spent_equipment))),
    return_equipment_id = (select q.id from gestao_interv.equipment_list q where lower(q.name) = lower(btrim(i.equipment_return)))
  where not i.material_migrated;

  -- acessórios (com quantidade = nº de vezes que aparecem no registo)
  delete from gestao_interv.intervention_accessories ia
  using gestao_interv.interventions i
  where ia.intervention_id = i.id and not i.material_migrated;

  insert into gestao_interv.intervention_accessories (intervention_id, accessory_id, direction, quantity)
  select i.id, ac.id, x.dir, count(*)
  from gestao_interv.interventions i
  cross join lateral (values
    ('gasto', i.accessory_spent_1), ('gasto', i.accessory_spent_2), ('gasto', i.accessory_spent_3),
    ('gasto', i.accessory_spent_4), ('gasto', i.accessory_spent_5),
    ('retomado', i.accessory_return_1), ('retomado', i.accessory_return_2), ('retomado', i.accessory_return_3),
    ('retomado', i.accessory_return_4), ('retomado', i.accessory_return_5)
  ) as x(dir, name)
  join gestao_interv.accessories ac on lower(ac.name) = lower(btrim(x.name))
  where not i.material_migrated
  group by i.id, ac.id, x.dir;

  update gestao_interv.interventions set material_migrated = true where not material_migrated;
  get diagnostics n = row_count;
  return n;
end $$;

select gestao_interv.backfill_material();

-- =============================================================================
-- Notificação automática à financeira (email enviado pela conta Google do utilizador)
-- =============================================================================
alter table profiles
  add column if not exists google_refresh_token text,          -- cifrado (AES-256-GCM, chave derivada de AUTH_SECRET)
  add column if not exists gmail_send_granted_at timestamptz;

alter table interventions
  add column if not exists billing_notified_at timestamptz,    -- quando o email à financeira foi enviado
  add column if not exists billing_notified_by text,           -- conta que enviou
  add column if not exists billing_notify_error text;          -- último erro de envio (se houver)

-- Definições da aplicação (ex.: conta de envio de emails ligada por um admin)
create table if not exists app_settings (
  key        text primary key,
  value      text,
  updated_at timestamptz not null default now(),
  updated_by text
);

-- =============================================================================
-- Integração com a Intranet Frotcom (clientes = accounts, IMEIs = devices)
-- =============================================================================
alter table clients
  add column if not exists intranet_account_id text,
  add column if not exists intranet_short_name text,
  add column if not exists intranet_synced_at  timestamptz;
-- (antes era único; agora uma conta pode ter vários clientes — ver fim do ficheiro)

create table if not exists devices (
  imei                text primary key,
  intranet_device_id  text,
  intranet_account_id text,
  client_id           uuid references clients(id),
  model               text,
  license_plate       text,
  active              boolean not null default true,
  synced_at           timestamptz not null default now()
);
create index if not exists devices_client_idx on devices (client_id);
create index if not exists devices_account_idx on devices (intranet_account_id);

-- Contas da Intranet sem correspondência automática, à espera de decisão (associar / criar / ignorar)
create table if not exists intranet_pending (
  intranet_account_id text primary key,
  name                text not null,
  full_name           text,
  status              text not null default 'pending' check (status in ('pending', 'ignored')),
  first_seen_at       timestamptz not null default now(),
  last_seen_at        timestamptz not null default now()
);

-- origem do cliente ('intranet_manual' = criado com "Criar novo" em Configurações → Intranet)
alter table clients add column if not exists created_via text;

-- =============================================================================
-- IMEI do equipamento retomado + histórico matrícula → IMEI (construído a cada sincronização)
-- =============================================================================
alter table interventions add column if not exists return_equipment_imei text;

create or replace function gestao_interv.plate_norm(p text) returns text
language sql immutable as $$ select nullif(upper(regexp_replace(coalesce(p, ''), '[^A-Za-z0-9]', '', 'g')), '') $$;

create table if not exists device_plate_history (
  id            bigserial primary key,
  plate_norm    text not null,
  license_plate text,
  imei          text not null,
  client_id     uuid references clients(id),
  model         text,
  seen_from     timestamptz not null default now(),
  seen_to       timestamptz          -- null = é o IMEI atual dessa matrícula
);
create index if not exists device_plate_history_plate_idx on device_plate_history (plate_norm, seen_to);
create index if not exists interventions_plate_norm_idx on interventions (gestao_interv.plate_norm(license_plate));

-- Edição de registos: quem alterou por último
alter table interventions add column if not exists updated_by text;

-- Nomes antigos (da Google Sheet) de clientes renomeados para o nome da Intranet — usados na re-importação de CSVs
alter table clients add column if not exists sheet_names text[];

-- Coluna nova da Sheet: "Serviços da conta - driving Behavior / sensor de porta"
alter table interventions add column if not exists account_services text;

-- Uma conta da Intranet pode estar ligada a vários clientes da BD (ex.: venda e aluguer da mesma empresa)
drop index if exists gestao_interv.clients_intranet_uq;
create index if not exists clients_intranet_idx on clients (intranet_account_id) where intranet_account_id is not null;

-- Kits: acessórios que acompanham cada equipamento (sugeridos automaticamente no formulário)
create table if not exists equipment_kit_items (
  equipment_id uuid not null references equipment_list(id) on delete cascade,
  accessory_id uuid not null references accessories(id) on delete cascade,
  quantity     int  not null default 1 check (quantity between 1 and 99),
  primary key (equipment_id, accessory_id)
);

-- Correspondência manual "hardware" da Intranet → equipamento da lista (quando a automática não chega)
create table if not exists hardware_map (
  hardware     text primary key,
  equipment_id uuid not null references equipment_list(id) on delete cascade,
  updated_at   timestamptz not null default now(),
  updated_by   text
);

-- =============================================================================
-- Stock de equipamentos (por IMEI)
-- Cada movimento leva um IMEI de um armazém (from) para outro (to).
-- from nulo = entra no stock (receção, retoma); to nulo = sai do stock (instalado numa intervenção).
-- A posição atual de cada IMEI é o último movimento (view stock_current).
-- =============================================================================
create table if not exists stock_movements (
  id                uuid primary key default gen_random_uuid(),
  imei              text not null,
  equipment_id      uuid references equipment_list(id),
  kind              text not null check (kind in ('rececao', 'transferencia', 'intervencao_saida', 'intervencao_entrada', 'ajuste')),
  from_warehouse_id uuid references warehouses(id),
  to_warehouse_id   uuid references warehouses(id),
  modality          text check (modality in ('Venda', 'Aluguer')),
  intervention_id   uuid references interventions(id) on delete cascade,
  moved_at          date not null default current_date,
  notes             text,
  created_by        text,
  created_at        timestamptz not null default now(),
  seq               bigserial
);
create index if not exists stock_movements_imei_idx on stock_movements (imei, moved_at desc, seq desc);
create index if not exists stock_movements_interv_idx on stock_movements (intervention_id);

alter table interventions add column if not exists return_modality text;

-- IMEIs a ignorar em toda a app (números inválidos / de teste): não contam no stock nem são sincronizados da Intranet
create table if not exists gestao_interv.ignored_imeis (
  imei       text primary key,
  reason     text,
  created_by text,
  created_at timestamptz not null default now()
);

create or replace view stock_current as
select distinct on (m.imei)
       m.imei, m.to_warehouse_id as warehouse_id, m.moved_at, m.kind, m.intervention_id,
       coalesce(m.equipment_id, (select m2.equipment_id from stock_movements m2 where m2.imei = m.imei and m2.equipment_id is not null
                                 order by m2.moved_at desc, m2.seq desc limit 1)) as equipment_id,
       coalesce(m.modality, (select m3.modality from stock_movements m3 where m3.imei = m.imei and m3.modality is not null
                             order by m3.moved_at desc, m3.seq desc limit 1)) as modality
from stock_movements m
order by m.imei, m.moved_at desc, m.seq desc;

/** Normaliza texto de venda/aluguer */
create or replace function gestao_interv.modality_of(v text) returns text language sql immutable as $$
  select case when v ilike '%alug%' then 'Aluguer' when v ilike '%vend%' then 'Venda' else null end
$$;

-- IMEI normalizado: sem espaços; 14 dígitos a começar por 1 = IMEI a que o Excel tirou o 0 inicial → repõe o 0
create or replace function gestao_interv.imei_norm(v text) returns text language sql immutable as $$
  -- números fictícios da Intranet (80000000000xxxx, equipamentos virtuais) não são IMEIs reais → ignorados
  select case when btrim(v) ~ '^80{6}' then null when btrim(v) ~ '^1[0-9]{13}$' then '0' || btrim(v) else nullif(btrim(v), '') end
$$;
-- corrige movimentos manuais já gravados com o 0 em falta (idempotente)
update gestao_interv.stock_movements set imei = '0' || imei where imei ~ '^1[0-9]{13}$';

-- Só contam para stock IMEIs com 15 dígitos (equipamentos). Números mais curtos (acessórios, sensores, cartões…) não movimentam stock.
/**
 * Movimentos de stock implícitos em cada intervenção (serve para as importadas da Sheet e para as novas):
 *  - armazém de saída E de entrada, com um só IMEI (gasto = IMEI, ou só IMEI) → transferência
 *    (ex.: "Entrada de Material", "Envio de material", "Envio RMA")
 *  - armazém de saída → sai o IMEI gasto (ou o IMEI, se não houver gasto)          (ex.: instalação)
 *  - armazém de entrada → entra o IMEI retomado (ou o IMEI, se for diferente do gasto) (ex.: desinstalação, troca)
 */
-- no mesmo dia: primeiro as entradas (desinstalação), depois transferências, por fim as saídas (instalação)
alter table gestao_interv.interventions add column if not exists extra_imeis text;
create or replace view gestao_interv.intervention_stock_moves as
with b as (
  -- uma linha por IMEI: o IMEI da intervenção + os "IMEIs adicionais" (logística com vários equipamentos, ex.: Entrega de Material)
  select i.*,
         case when xx.xv is null then gestao_interv.imei_norm(i.imei) else xx.xv end as im,
         case when xx.xv is null then gestao_interv.imei_norm(i.spent_equipment_imei) else xx.xv end as sp,
         case when xx.xv is null then gestao_interv.imei_norm(i.return_equipment_imei) end as rt,
         -- armazém de entrada efetivo: o indicado; se faltar e houver equipamento retirado da viatura (IMEI retomado),
         -- entra no stock Frotcom da modalidade: Aluguer → "A2 - …", Venda → "A1 - …" (ex.: upgrade sem armazém de entrada)
         coalesce(i.stock_entry_warehouse_id,
           case when xx.xv is null and gestao_interv.imei_norm(i.return_equipment_imei) is not null then
             (select w.id from gestao_interv.warehouses w
               where w.active and w.name ilike (case when gestao_interv.modality_of(coalesce(i.return_modality, i.venda_aluguer)) = 'Venda' then 'A1 %' else 'A2 %' end)
               order by w.name limit 1) end) as entry_wh
  from gestao_interv.interventions i
  cross join lateral (
    select null::text as xv
    union all
    select distinct gestao_interv.imei_norm(x) from regexp_split_to_table(coalesce(i.extra_imeis, ''), '[\s,;]+') x
    where gestao_interv.imei_norm(x) is not null
      and gestao_interv.imei_norm(x) is distinct from gestao_interv.imei_norm(i.imei)
      and gestao_interv.imei_norm(x) is distinct from gestao_interv.imei_norm(i.spent_equipment_imei)
  ) xx
), c as (
  select b.*,
         -- tipos de logística: o IMEI da intervenção é o próprio material movimentado (entra/sai tal como está)
         exists (select 1 from gestao_interv.intervention_types t where t.id = b.intervention_type_id
                 and lower(btrim(t.name)) = any(array['envio de material', 'envio rma', 'entrada de material', 'entrada de rma',
                   'entrega de material', 'entrega de material try and buy', 'recolha de material',
                   'desinstalação try and buy', 'desinstalação', 'acerto de stock'])) as is_logistic,
         -- intervenções na viatura (instalação, assistência, upgrade, troca…; não logística nem desinstalação):
         -- o IMEI com que a viatura fica está instalado, por isso sai do stock mesmo sem armazém de saída indicado
         exists (select 1 from gestao_interv.intervention_types t where t.id = b.intervention_type_id
                 and t.name not ilike '%desinstala%') as is_field_type,
         (stock_exit_warehouse_id is not null and stock_entry_warehouse_id is not null and rt is null
          and (sp is null or im is null or sp = im)
          and has_spent_eq and has_return_eq
          -- só é transferência entre armazéns diferentes e quando não é uma intervenção numa viatura
          -- (ex.: instalação com equipamento retirado sem IMEI e os dois armazéns = Stock Frotcom → é saída, não transferência)
          and stock_exit_warehouse_id <> stock_entry_warehouse_id
          and (b.lg or nullif(btrim(b.license_plate), '') is null)) as is_transfer
  from (select b.*,
               -- só há movimento de stock quando há EQUIPAMENTO (não só acessórios) do lado respetivo;
               -- na logística basta o "Equipamentos" (equipamento principal) + IMEI
               (sp is not null or spent_equipment_id is not null or nullif(btrim(spent_equipment), '') is not null
                or (b.lg and b.equipment_id is not null and b.im is not null)) as has_spent_eq,
               (rt is not null or return_equipment_id is not null or nullif(btrim(equipment_return), '') is not null
                or (b.lg and b.equipment_id is not null and b.im is not null)) as has_return_eq
        from (select b.*, exists (select 1 from gestao_interv.intervention_types t where t.id = b.intervention_type_id
                 and lower(btrim(t.name)) = any(array['envio de material', 'envio rma', 'entrada de material', 'entrada de rma',
                   'entrega de material', 'entrega de material try and buy', 'recolha de material',
                   'desinstalação try and buy', 'desinstalação', 'acerto de stock'])) as lg from b) b) b
)
select id as intervention_id, coalesce(sp, im) as imei, coalesce(spent_equipment_id, equipment_id) as equipment_id,
       'transferencia'::text as kind, stock_exit_warehouse_id as from_wh, stock_entry_warehouse_id as to_wh,
       coalesce(return_modality, gestao_interv.modality_of(venda_aluguer)) as modality, intervention_date, coalesce(updated_by, created_by) as by, created_at, 2 as ord
from c where is_transfer and coalesce(sp, im) ~ '^[0-9]{15}$'
union all
-- equipamento instalado: Aluguer → fica no armazém "Instalado Aluguer (Mobilizado)"; Venda → sai do stock
select id, coalesce(sp, im), coalesce(spent_equipment_id, equipment_id), 'intervencao_saida', stock_exit_warehouse_id,
       case when gestao_interv.modality_of(venda_aluguer) = 'Aluguer' then gestao_interv.mobilized_wh() end,
       gestao_interv.modality_of(venda_aluguer), intervention_date, coalesce(updated_by, created_by), created_at, 3
from c where not is_transfer and coalesce(sp, im) ~ '^[0-9]{15}$'
  and ((stock_exit_warehouse_id is not null and has_spent_eq)
       -- intervenção na viatura (instalação, reinstalação, troca…) com matrícula: o IMEI com que a viatura fica está instalado
       -- e sai do stock — com ou sem armazém de saída, e mesmo que só o campo IMEI esteja preenchido (registos antigos)
       or (is_field_type and not is_logistic and nullif(btrim(license_plate), '') is not null
           -- a não ser que esse IMEI seja o que entra no armazém (equipamento retirado)
           and not (stock_entry_warehouse_id is not null and has_return_eq and coalesce(rt, im) = coalesce(sp, im) and sp is null)))
union all
select id, coalesce(rt, case when is_logistic then coalesce(sp, im) when im is distinct from sp then im end),
       coalesce(return_equipment_id, case when is_logistic then spent_equipment_id end, equipment_id), 'intervencao_entrada', null, entry_wh,
       coalesce(return_modality, gestao_interv.modality_of(venda_aluguer)), intervention_date, coalesce(updated_by, created_by), created_at, 1
from c where not is_transfer and entry_wh is not null and has_return_eq
  -- numa intervenção de logística só com armazém de entrada, o material entra (não há saída)
  and not (is_logistic and stock_exit_warehouse_id is not null)
  and coalesce(rt, case when is_logistic then coalesce(sp, im) when im is distinct from sp then im end) ~ '^[0-9]{15}$'
union all
-- Desinstalação sem armazém de entrada nem IMEI retomado (ex.: registos importados só com o IMEI):
--   Aluguer → o IMEI sai do Mobilizado e entra no armazém do técnico que fez a intervenção;
--   Venda → o equipamento é do cliente, não entra no nosso stock (ver a regra seguinte)
select c.id, c.im, c.equipment_id, 'intervencao_entrada', null, tw.id, 'Aluguer', c.intervention_date, coalesce(c.updated_by, c.created_by), c.created_at, 1
from c
join gestao_interv.intervention_types it on it.id = c.intervention_type_id and it.name ilike '%desinstala%'
left join gestao_interv.technicians t on t.id = c.technician_id
join lateral (select w.id from gestao_interv.warehouses w
              where lower(btrim(w.name)) = lower(btrim(t.name)) and w.type <> 'mobilizado' limit 1) tw on true
where not c.is_transfer and c.entry_wh is null and c.rt is null
  and gestao_interv.modality_of(c.venda_aluguer) = 'Aluguer'
  and c.im ~ '^[0-9]{15}$'
union all
-- Desinstalação de Venda sem armazém de entrada: o equipamento é do cliente → não pode continuar no nosso stock.
-- Se a app ainda o tinha num armazém (instalação nunca registada), sai do stock nesta data.
select c.id, c.im, c.equipment_id, 'intervencao_saida', null, null, 'Venda', c.intervention_date, coalesce(c.updated_by, c.created_by), c.created_at, 3
from c
join gestao_interv.intervention_types it on it.id = c.intervention_type_id and it.name ilike '%desinstala%'
where not c.is_transfer and c.entry_wh is null and c.rt is null
  and gestao_interv.modality_of(c.venda_aluguer) = 'Venda'
  and c.im ~ '^[0-9]{15}$';

create or replace function gestao_interv.sync_intervention_stock(p_id uuid) returns void language plpgsql as $$
begin
  delete from gestao_interv.stock_movements where intervention_id = p_id;
  insert into gestao_interv.stock_movements (imei, equipment_id, kind, from_warehouse_id, to_warehouse_id, modality, intervention_id, moved_at, created_by)
  select imei, equipment_id, kind, from_wh, to_wh, modality, intervention_id, intervention_date, by
  from gestao_interv.intervention_stock_moves where intervention_id = p_id order by ord;
end $$;

/** Recalcula os movimentos de todas as intervenções (histórico). Devolve o nº de movimentos. */
create or replace function gestao_interv.rebuild_intervention_stock() returns int language plpgsql as $$
declare n int;
begin
  delete from gestao_interv.stock_movements where intervention_id is not null;
  insert into gestao_interv.stock_movements (imei, equipment_id, kind, from_warehouse_id, to_warehouse_id, modality, intervention_id, moved_at, created_by, created_at)
  select imei, equipment_id, kind, from_wh, to_wh, modality, intervention_id, intervention_date, by, created_at
  from gestao_interv.intervention_stock_moves
  order by intervention_date, ord, created_at;
  get diagnostics n = row_count;
  return n;
end $$;

-- Email do técnico/validador (para atribuir automaticamente o "Validado por" pelo email de login)
alter table technicians add column if not exists email text;
create unique index if not exists technicians_email_uq on technicians (lower(email)) where email is not null;

-- Contas internas da Frotcom (ex.: "Frotcom Lusitana", "Frotcom Lusitana - Transit", e a conta de demonstração "demopt"): os IMEIs lá não contam como instalados
create or replace function gestao_interv.is_internal_account(p_account text) returns boolean language sql stable as $$
  select p_account is not null and exists (
    select 1 from gestao_interv.clients c where c.intranet_account_id = p_account
      and (c.name ~* '(frotcom lusitana|^demopt$|^testing$)' or c.intranet_short_name ~* '(frotcom lusitana|^demopt$|^testing$)')
    union all
    select 1 from gestao_interv.intranet_pending p where p.intranet_account_id = p_account
      and (p.name ~* '(frotcom lusitana|^demopt$|^testing$)' or p.full_name ~* '(frotcom lusitana|^demopt$|^testing$)'))
$$;

-- Correções manuais do stock (“Dar saída” pela Intranet): deixam de contar quando, depois delas,
-- é registada ou editada uma intervenção com o mesmo IMEI (a informação real passa à frente)
alter table stock_movements add column if not exists is_correction boolean not null default false;
alter table stock_movements add column if not exists superseded_at timestamptz;
update stock_movements set is_correction = true
 where not is_correction and intervention_id is null
   and (kind = 'ajuste' or notes like 'Transferido (Intranet mostra%');

create or replace view stock_current as
select distinct on (m.imei)
       m.imei, m.to_warehouse_id as warehouse_id, m.moved_at, m.kind, m.intervention_id,
       coalesce(m.equipment_id, (select m2.equipment_id from stock_movements m2 where m2.imei = m.imei and m2.equipment_id is not null
                                 order by m2.moved_at desc, m2.seq desc limit 1)) as equipment_id,
       coalesce(m.modality, (select m3.modality from stock_movements m3 where m3.imei = m.imei and m3.modality is not null
                             order by m3.moved_at desc, m3.seq desc limit 1)) as modality
from stock_movements m
where m.superseded_at is null and m.imei !~ '^80{6}'
  and not exists (select 1 from gestao_interv.ignored_imeis ig where ig.imei = m.imei)
order by m.imei, m.moved_at desc, m.seq desc;

/** Marca como substituídas as correções dos IMEIs de uma intervenção (chamado ao registar/editar/importar) */
create or replace function gestao_interv.supersede_corrections(p_intervention uuid) returns int language plpgsql as $$
declare n int;
begin
  update gestao_interv.stock_movements m set superseded_at = now()
  from gestao_interv.interventions i
  where i.id = p_intervention and m.is_correction and m.superseded_at is null
    and m.imei in (gestao_interv.imei_norm(i.imei), gestao_interv.imei_norm(i.spent_equipment_imei), gestao_interv.imei_norm(i.return_equipment_imei))
    -- só se a intervenção é posterior (ou do mesmo dia) à correção; importações de intervenções antigas não anulam correções
    and i.intervention_date >= m.moved_at;
  get diagnostics n = row_count;
  -- transferências manuais feitas ANTES de esta intervenção ser gravada, com data posterior à saída que ela regista:
  -- foram feitas com informação desatualizada (o IMEI já tinha saído) → deixam de contar
  update gestao_interv.stock_movements m set superseded_at = now()
  from gestao_interv.stock_movements s
  where s.intervention_id = p_intervention and s.kind = 'intervencao_saida'
    and m.imei = s.imei and m.intervention_id is null and m.kind = 'transferencia'
    and m.superseded_at is null and m.moved_at >= s.moved_at and m.created_at < s.created_at
    and not exists (select 1 from gestao_interv.stock_movements x
                    where x.imei = m.imei and x.intervention_id is not null and x.id <> s.id
                      and x.moved_at between s.moved_at and m.moved_at and (x.moved_at, x.seq) > (s.moved_at, s.seq));
  return n;
end $$;

-- repara correções marcadas como substituídas por intervenções com data anterior (ex.: reimportação da Sheet)
update gestao_interv.stock_movements m set superseded_at = null
where m.is_correction and m.superseded_at is not null
  and not exists (
    select 1 from gestao_interv.interventions i
    where m.imei in (gestao_interv.imei_norm(i.imei), gestao_interv.imei_norm(i.spent_equipment_imei), gestao_interv.imei_norm(i.return_equipment_imei))
      and i.intervention_date >= m.moved_at);

-- Papel "financeiro": só consulta e marca intervenções faturáveis como processadas
alter table profiles drop constraint if exists profiles_role_check;
alter table profiles add constraint profiles_role_check check (role in ('admin', 'user', 'financeiro'));
alter table interventions
  add column if not exists billing_processed_at timestamptz,
  add column if not exists billing_processed_by text;

-- Data de envio ("Shipped on") do equipamento na Intranet — usada na receção automática de material novo (A1)
alter table devices add column if not exists shipped_on date;

-- =============================================================================
-- Stock de ACESSÓRIOS (por quantidades)
--  - accessory_stock_items: lista de acessórios que contam para stock (nomes "oficiais")
--  - accessory_stock_map:   nomes da BD (accessories) que correspondem a cada item (vários → um)
--  - accessory_movements:   receções, transferências, contagens (acerto) e ajustes manuais
--  - intervenções: gasto = sai do armazém de saída (ou do armazém do técnico); retomado = entra no de entrada (ou do técnico)
--  - stock = última contagem do armazém + movimentos posteriores (sem contagem: todo o histórico)
-- =============================================================================
create table if not exists accessory_stock_items (
  id         uuid primary key default gen_random_uuid(),
  name       text not null,
  active     boolean not null default true,
  created_at timestamptz not null default now()
);
create unique index if not exists accessory_stock_items_name_uq on accessory_stock_items (lower(btrim(name)));

create table if not exists accessory_stock_map (
  accessory_id uuid primary key references accessories(id) on delete cascade,
  item_id      uuid not null references accessory_stock_items(id) on delete cascade
);

create table if not exists accessory_movements (
  id           uuid primary key default gen_random_uuid(),
  item_id      uuid not null references accessory_stock_items(id) on delete cascade,
  warehouse_id uuid references warehouses(id),
  kind         text not null check (kind in ('rececao', 'transferencia', 'contagem', 'ajuste')),
  quantity     int  not null,            -- contagem: quantidade contada; restantes: +entra / −sai
  group_id     uuid,                     -- as duas linhas de uma transferência
  moved_at     date not null default current_date,
  notes        text,
  created_by   text,
  created_at   timestamptz not null default now()
);
create index if not exists accessory_movements_item_idx on accessory_movements (item_id, warehouse_id, moved_at);

-- lista inicial (só insere o que ainda não existe)
insert into accessory_stock_items (name) select n from unnest(array[
  'Garmin 770', 'Garmin Fleet 780 com câmara', 'Garmin Fleet 790', 'ALLCAN300 Adapter (FMC130)', 'Antena C4MAX',
  'BLE EYE_Beacon', 'BLE EYE Sensor', 'ELA - BLE "Blue PUCK T EN12830" - Temp Sensor', 'CAN100BLE',
  'CL-CAN (Contactless-CAN) adapter', 'Smart Card Reader', 'Carrier reefer cable', 'IBUTTON AMI',
  'DR102 Automatic Driver Identification RFID', 'Sensor Porta - Schmersal', 'Inventure FMS Gateway', 'Front Panel Cable',
  'IOBOX CAN (FOX3)', 'LV-CAN200', 'LV-CAN200 (FMC640)', 'PB-1 Panic Button', 'TS-1 One Wire Temperature Sensor',
  'TS2-1W One Wire Temperature Sensor', 'Imobilizador Viaturas - 12V', 'Imobilizador 24V', 'MIO F740S',
  'Licença Sygic 3 years', 'Licença Sygic 5 years', 'Puck Holder Sticker', 'AC100 Converter Cable', 'CAN100',
  'ID-IBUTTON RS AMIDATA', 'Buzzer', 'Garmin 670 EU Navigator', 'Leitor Cartões RFID', 'IBP-1 Automatic Driver ID',
  'LYTX AI-12 DASHCAM', 'DC-1 Data Cable']) n
where not exists (select 1 from accessory_stock_items i where lower(btrim(i.name)) = lower(btrim(n)));

-- correspondência automática proposta (só para acessórios ainda sem correspondência; editável em Configurações)
insert into accessory_stock_map (accessory_id, item_id)
select distinct on (a.id) a.id, i.id
from accessories a
join (values
  ('Garmin 770', '^garmin.*770'), ('Garmin Fleet 780 com câmara', 'garmin.*780'), ('Garmin Fleet 790', 'garmin.*790'),
  ('ALLCAN300 Adapter (FMC130)', 'all ?can ?300'), ('Antena C4MAX', '^antena c4max'), ('BLE EYE_Beacon', 'eye ?beacon'),
  ('BLE EYE Sensor', 'eye ?sensor'), ('ELA - BLE "Blue PUCK T EN12830" - Temp Sensor', '(ble ela|blue ?puck)'),
  ('CAN100BLE', '^can ?100 ?ble'), ('CL-CAN (Contactless-CAN) adapter', '^cl[ -]?can'), ('Smart Card Reader', 'smart ?card'),
  ('Carrier reefer cable', '(carrier|ref+e+r)'), ('IBUTTON AMI', '^ibutton$'), ('DR102 Automatic Driver Identification RFID', '^dr ?10[0-2]'),
  ('Sensor Porta - Schmersal', 'sensor(es)? de porta'), ('Inventure FMS Gateway', '^inventure'), ('Front Panel Cable', 'front ?panel'),
  ('IOBOX CAN (FOX3)', '^io ?box ?can'), ('LV-CAN200 (FMC640)', '(lv ?-?200 ?can|lv ?-?can ?200).*640'),
  ('LV-CAN200', '^(lv ?-?200 ?can|lv ?-?can ?200)$'), ('PB-1 Panic Button', '(p[aâ]nico|panic)'),
  ('Imobilizador Viaturas - 12V', '(imobiliz.*12|^rel[eé] 12v$)'), ('Imobilizador 24V', '(imobiliz.*24|^rel[eé]s? 24v$)'),
  ('MIO F740S', '^mio( |$)'), ('Licença Sygic 3 years', 'syg[iy]c.*3'), ('Licença Sygic 5 years', 'syg[iy]c.*5'),
  ('Puck Holder Sticker', 'puck ?holder'), ('AC100 Converter Cable', '^ac ?100'), ('CAN100', '^can ?100$'),
  ('ID-IBUTTON RS AMIDATA', '(amidata|^pen id ibutton)'), ('Buzzer', '^buzzer'), ('Garmin 670 EU Navigator', '^garmin.*670'),
  ('Leitor Cartões RFID', '(^rfid$|leitor.*rfid)'), ('IBP-1 Automatic Driver ID', '^ibp ?-?1'), ('LYTX AI-12 DASHCAM', '(lytx|dashcam)'),
  ('DC-1 Data Cable', '^dc ?-?1( |$)')
) r(item, pat) on a.name ~* r.pat
join accessory_stock_items i on lower(btrim(i.name)) = lower(btrim(r.item))
where not exists (select 1 from accessory_stock_map m where m.accessory_id = a.id)
  and not exists (select 1 from app_settings s where s.key = 'accessory_map_seeded')
order by a.id, length(r.pat) desc
on conflict (accessory_id) do nothing;
insert into app_settings (key, value, updated_by) values ('accessory_map_seeded', 'sim', 'sistema') on conflict (key) do nothing;

-- movimentos de acessórios vindos das intervenções
create or replace view gestao_interv.accessory_intervention_moves as
select m.item_id,
       case when ia.direction = 'gasto' then coalesce(i.stock_exit_warehouse_id, tw.id) else coalesce(i.stock_entry_warehouse_id, tw.id) end as warehouse_id,
       case when ia.direction = 'gasto' then -ia.quantity else ia.quantity end as quantity,
       ia.direction, i.id as intervention_id, i.intervention_date as moved_at, i.created_at
from gestao_interv.intervention_accessories ia
join gestao_interv.accessory_stock_map m on m.accessory_id = ia.accessory_id
join gestao_interv.interventions i on i.id = ia.intervention_id
left join gestao_interv.technicians t on t.id = i.technician_id
left join lateral (select w.id from gestao_interv.warehouses w where lower(btrim(w.name)) = lower(btrim(t.name)) and w.type <> 'mobilizado' limit 1) tw on true
union all
-- Kit automático nas Entregas/Entradas de Material (a partir de 01/10/2026; as anteriores foram tratadas pelo
-- script backfill-kit-accessories): por cada equipamento que entra em stock, entram os acessórios do seu kit
-- — só quando a intervenção não regista nenhum acessório desse kit (se o técnico registar, vale o registado)
select km.item_id, sm.to_warehouse_id, (sm.n * k.quantity)::int, 'kit'::text, i.id, i.intervention_date, i.created_at
from (select m.intervention_id, m.equipment_id, m.to_warehouse_id, count(*)::int as n
      from gestao_interv.stock_movements m
      where m.kind = 'intervencao_entrada' and m.superseded_at is null and m.equipment_id is not null and m.to_warehouse_id is not null
      group by 1, 2, 3) sm
join gestao_interv.interventions i on i.id = sm.intervention_id and i.intervention_date >= date '2026-10-01'
join gestao_interv.intervention_types it on it.id = i.intervention_type_id
  and lower(btrim(it.name)) in ('entrega de material', 'entrada de material', 'entrega de material try and buy')
join gestao_interv.equipment_kit_items k on k.equipment_id = sm.equipment_id
join gestao_interv.accessory_stock_map km on km.accessory_id = k.accessory_id
where not exists (select 1 from gestao_interv.intervention_accessories ia
                  join gestao_interv.equipment_kit_items k2 on k2.accessory_id = ia.accessory_id and k2.equipment_id = sm.equipment_id
                  where ia.intervention_id = i.id);

-- Transferências de equipamento do A1/A2 para o armazém de um técnico (manuais ou de intervenções) levam os acessórios
-- do kit: saem do A1/A2 e entram no técnico (n.º de IMEIs × quantidade do kit). A partir de 16/10/2026.
-- Não se aplica quando a intervenção regista acessórios desse kit.
create or replace view gestao_interv.accessory_kit_transfer_moves as
with t as (
  select m.id, m.imei, m.moved_at, m.created_at, m.intervention_id, m.to_warehouse_id as to_wh,
         case when fw.active then m.from_warehouse_id
              else (select w.id from gestao_interv.warehouses w where w.active
                      and w.name ilike (case when coalesce(m.modality, 'Venda') = 'Aluguer' then 'A2 %' else 'A1 %' end)
                    order by w.name limit 1) end as from_wh,
         coalesce(m.equipment_id, (select m2.equipment_id from gestao_interv.stock_movements m2
                                   where m2.imei = m.imei and m2.equipment_id is not null and m2.moved_at <= m.moved_at
                                   order by m2.moved_at desc, m2.seq desc limit 1)) as equipment_id
  from gestao_interv.stock_movements m
  join gestao_interv.warehouses fw on fw.id = m.from_warehouse_id
  join gestao_interv.warehouses tw on tw.id = m.to_warehouse_id
  where m.kind = 'transferencia' and m.superseded_at is null
    and fw.type <> 'mobilizado' and tw.type <> 'mobilizado' and tw.active
    -- só a partir de 16/10/2026 (o histórico anterior acerta-se com contagens) e só do stock central (A1/A2)
    -- para o armazém de um técnico (armazém com o nome de um técnico)
    and m.moved_at >= date '2026-10-16'
    and (fw.name ilike 'A1 %' or fw.name ilike 'A2 %')
    and exists (select 1 from gestao_interv.technicians tt where lower(btrim(tt.name)) = lower(btrim(tw.name)))
), g as (
  select t.from_wh, t.to_wh, t.equipment_id, t.moved_at, t.intervention_id, min(t.created_at) as created_at, count(*)::int as n
  from t where t.equipment_id is not null and t.from_wh is not null and t.from_wh <> t.to_wh
    and (t.intervention_id is null or not exists (
          select 1 from gestao_interv.intervention_accessories ia
          join gestao_interv.equipment_kit_items k2 on k2.accessory_id = ia.accessory_id and k2.equipment_id = t.equipment_id
          where ia.intervention_id = t.intervention_id))
  group by 1, 2, 3, 4, 5
)
select km.item_id, g.from_wh as warehouse_id, -(g.n * k.quantity)::int as quantity, g.moved_at, g.created_at, g.intervention_id, g.to_wh as other_wh
from g join gestao_interv.equipment_kit_items k on k.equipment_id = g.equipment_id
join gestao_interv.accessory_stock_map km on km.accessory_id = k.accessory_id
union all
select km.item_id, g.to_wh, (g.n * k.quantity)::int, g.moved_at, g.created_at, g.intervention_id, g.from_wh
from g join gestao_interv.equipment_kit_items k on k.equipment_id = g.equipment_id
join gestao_interv.accessory_stock_map km on km.accessory_id = k.accessory_id;

-- stock atual por item e armazém
create or replace view gestao_interv.accessory_stock as
with all_moves as (
  select item_id, warehouse_id, 'intervencao'::text as kind, quantity, moved_at, created_at from gestao_interv.accessory_intervention_moves
  union all
  select item_id, warehouse_id, kind, quantity, moved_at, created_at from gestao_interv.accessory_movements
  union all
  select item_id, warehouse_id, 'kit_transferencia'::text, quantity, moved_at, created_at from gestao_interv.accessory_kit_transfer_moves
), last_count as (
  select distinct on (item_id, warehouse_id) item_id, warehouse_id, quantity, moved_at, created_at
  from gestao_interv.accessory_movements where kind = 'contagem'
  order by item_id, warehouse_id, moved_at desc, created_at desc
), keys as (
  select distinct item_id, warehouse_id from all_moves
)
select k.item_id, k.warehouse_id,
       coalesce(lc.quantity, 0) + coalesce((
         select sum(a.quantity) from all_moves a
         where a.item_id = k.item_id and a.warehouse_id is not distinct from k.warehouse_id and a.kind <> 'contagem'
           and (lc.item_id is null
                or a.moved_at > lc.moved_at
                or (a.kind <> 'intervencao' and a.moved_at = lc.moved_at and a.created_at > lc.created_at))), 0)::int as quantity,
       lc.moved_at as counted_at
from keys k
left join last_count lc on lc.item_id = k.item_id and lc.warehouse_id is not distinct from k.warehouse_id;

-- Contas de USO INTERNO (demonstração/testes): os IMEIs nelas devem estar no armazém "Uso Interno"
create or replace function gestao_interv.is_internal_use_account(p_account text) returns boolean language sql stable as $$
  select p_account is not null and exists (
    select 1 from gestao_interv.clients c where c.intranet_account_id = p_account
      and (c.name ~* '^(demopt|testing)$' or c.intranet_short_name ~* '^(demopt|testing)$')
    union all
    select 1 from gestao_interv.intranet_pending p where p.intranet_account_id = p_account
      and (p.name ~* '^(demopt|testing)$' or p.full_name ~* '^(demopt|testing)$'))
$$;

-- Stock mínimo por equipamento e armazém (alerta na tabela "Por equipamento e armazém")
create table if not exists gestao_interv.stock_minimums (
  equipment_id uuid not null references gestao_interv.equipment_list(id) on delete cascade,
  warehouse_id uuid not null references gestao_interv.warehouses(id) on delete cascade,
  min_qty      int  not null check (min_qty >= 0),
  updated_by   text,
  updated_at   timestamptz not null default now(),
  primary key (equipment_id, warehouse_id)
);

-- Super admin (perfil reservado): acessos extra (definições avançadas, escrita na Intranet). Só se ativa por script.
alter table gestao_interv.profiles add column if not exists is_superadmin boolean not null default false;

-- Registo das alterações feitas na Intranet pela app (super admin)
create table if not exists gestao_interv.intranet_write_log (
  id          uuid primary key default gen_random_uuid(),
  imei        text not null,
  old_plate   text,
  new_plate   text,
  old_account text,
  new_account text,
  ok          boolean not null,
  error       text,
  created_by  text,
  created_at  timestamptz not null default now()
);

-- Operador GSM do cartão (gsmOperator da Intranet): PT-Optimus → NOS, PT-Vodafone → VDF
alter table gestao_interv.devices add column if not exists gsm_operator text;

-- Pedidos de atualização de firmware feitos pela app (super admin)
create table if not exists gestao_interv.firmware_upgrade_log (
  id          uuid primary key default gen_random_uuid(),
  imei        text not null,
  kind        text not null default 'device' check (kind in ('device', 'canadapter')),
  previous    text,
  requested   text,
  firmware_id int,
  ok          boolean not null,
  error       text,
  created_by  text,
  created_at  timestamptz not null default now()
);

-- ===== Perfis configuráveis (RBAC por menu) =====
create table if not exists roles (
  name       text primary key,
  label      text not null,
  builtin    boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists role_permissions (
  role   text not null references roles(name) on update cascade on delete cascade,
  module text not null,
  level  text not null check (level in ('none', 'read', 'write')),
  primary key (role, module)
);
insert into roles (name, label, builtin) values
  ('admin', 'Administrador', true), ('user', 'Utilizador', true), ('financeiro', 'Financeiro', true)
on conflict (name) do nothing;
insert into role_permissions (role, module, level) values
  ('user','interventions','read'), ('user','stock','read'), ('user','accessories','read'), ('user','equipment','write'),
  ('user','reports','read'), ('user','settings','none'), ('user','billing','none'),
  ('financeiro','interventions','read'), ('financeiro','stock','read'), ('financeiro','accessories','read'), ('financeiro','equipment','write'),
  ('financeiro','reports','read'), ('financeiro','settings','none'), ('financeiro','billing','write')
on conflict (role, module) do nothing;
-- o papel passa a ser qualquer perfil da tabela roles
alter table profiles drop constraint if exists profiles_role_check;
